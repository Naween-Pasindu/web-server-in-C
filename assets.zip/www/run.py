f= open("style.css","r")
print(f.read())
print(len(str(f)))
